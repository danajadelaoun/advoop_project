package com.advoop;

import java.util.ArrayList;
import java.util.List;


public class customers {
    private List<customer> customerList = new ArrayList<>();
    private static customers ourInstance = new customers();

    public static customers getInstance() {
        return ourInstance;
    }
 
    public List<customer> getcustomerList() {
        return customerList;
    }
 
    public void getcustomerList(List<customer> customerList) {
        this.customerList = customerList;
    }
    
    public void createcustomer(customer customer) {
    	customerList.add(customer);
    }
    
    public customer getcustomerbyid(int id) {
        for (customer customer : customerList) {
            if (customer.getid()==id)
            {
                return customer;
            }
        }

        return null;
    }
}
