package com.advoop;

import javax.swing.*;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DomesticFlight extends JFrame {
	
	JComboBox CBFrom, CBTo, CBClass, CBAdult, CBChildren, CBInfant;
	JLabel LFrom, LTo, LBookingDate, LClass, LAdult, LChildren, LInfant, LBookingDetails, LPassengerDetails, LDate,
			LImg1, LImg2, LNotes;
	JTextField TFBookingDate;
	Icon img1, img2;
	JButton BFindFlight;
	JPanel PPanel1, PPanel2;

	flightrecord type1;

	public DomesticFlight(flightrecord type1) {
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		String[] sItem1 = { "Lebanon" };
		String[] sItem2 = { "Bangalore", "Chennai ", "Delhi", "Goa", "Hyderabad", "Kolkata", "Lucknow", "Mumbai",
				"Vishakapatnam" };
		String[] sItem3 = { "Economic", "Business" };

		this.type1 = type1;
		PPanel1 = new JPanel(null);
		PPanel1.setPreferredSize(new Dimension(459, 200));

		LBookingDetails = new JLabel("<html><b><font color=\"#C71585\">Booking Details</font></b></html>");
		LFrom = new JLabel("From          :");
		LTo = new JLabel("To               :");
		LBookingDate = new JLabel("Booking Date:");
		LClass = new JLabel("Class         :");

		CBFrom = new JComboBox<Object>(sItem1);
		CBTo = new JComboBox<Object>(sItem2);
		CBClass = new JComboBox<Object>(sItem3);

		TFBookingDate = new JTextField(10);
		LDate = new JLabel("(DD/MM/YYYY)");
		LDate.setForeground(Color.red);

		img1 = new ImageIcon("map1.jpg");
		LImg1 = new JLabel(img1);

		BFindFlight = new JButton("Find Flight");

		LBookingDetails.setBounds(20, 3, 100, 20);

		LFrom.setBounds(20, 40, 100, 20);
		CBFrom.setBounds(100, 40, 100, 20);

		LTo.setBounds(20, 100, 100, 20);
		CBTo.setBounds(100, 100, 100, 20);

		LBookingDate.setBounds(14, 160, 100, 20);
		TFBookingDate.setBounds(100, 160, 100, 20);
		LDate.setBounds(210, 160, 100, 20);

		LClass.setBounds(20, 220, 100, 20);
		CBClass.setBounds(100, 220, 100, 20);

		BFindFlight.setBounds(50, 270, 100, 25);

		LImg1.setBounds(0, 290, 495, 260);

		PPanel1.add(LBookingDetails);
		PPanel1.add(LFrom);
		PPanel1.add(CBFrom);
		PPanel1.add(LTo);
		PPanel1.add(CBTo);
		PPanel1.add(LBookingDate);
		PPanel1.add(TFBookingDate);
		PPanel1.add(LDate);
		PPanel1.add(LClass);
		PPanel1.add(CBClass);
		PPanel1.add(BFindFlight);
		PPanel1.add(LImg1);
		PPanel1.setBackground(Color.white);

		c.add(PPanel1, BorderLayout.WEST);

		PPanel2 = new JPanel(null);
		PPanel2.setPreferredSize(new Dimension(320, 160));

		LPassengerDetails = new JLabel("<html><b><font color=\"#C71585\">PassengerDetails</font></b></html>");

		LAdult = new JLabel("Adults(12+)");

		LChildren = new JLabel("Children(2-11)");
		LInfant = new JLabel("Infants(under 2)");

		String[] item4 = { "1", "2", "3", "4", "5", "6" };
		CBAdult = new JComboBox<Object>(item4);

		String[] item5 = { "0", "1", "2", "3", "4" };
		CBChildren = new JComboBox<Object>(item5);

		String[] item6 = { "0", "1", "2", "3" };
		CBInfant = new JComboBox<Object>(item6);

		img2 = new ImageIcon("note_bg.gif");
		LImg2 = new JLabel(img2);
		LNotes = new JLabel(
				"<html><b><p>NOTE: Bookings with International Credit Cards <p> have temporarily been suspended.This Service<p> will resume shortly and we will have a notice<p> posted on our website.We regret any <p>inconvenience caused to our passengers.</b></html>");

		LPassengerDetails.setBounds(40, 3, 100, 20);

		LAdult.setBounds(40, 40, 100, 20);
		CBAdult.setBounds(140, 40, 100, 20);

		LChildren.setBounds(40, 105, 100, 20);
		CBChildren.setBounds(140, 105, 100, 20);

		LInfant.setBounds(40, 170, 100, 20);
		CBInfant.setBounds(140, 170, 100, 20);

		LImg2.setBounds(16, 220, 320, 200);
		LNotes.setBounds(55, 240, 380, 180);

		PPanel2.add(LPassengerDetails);
		PPanel2.add(LAdult);
		PPanel2.add(LChildren);
		PPanel2.add(LInfant);
		PPanel2.add(CBAdult);
		PPanel2.add(CBChildren);
		PPanel2.add(CBInfant);

		PPanel2.add(LNotes);
		PPanel2.add(LImg2);

		PPanel2.setBackground(Color.white);

		c.add(PPanel2, BorderLayout.EAST);

		setSize(795, 580);
		setVisible(true);

		BFindFlight.addActionListener(new button3(this, type1));
	}

	public static void main(String args[]) {
		flightrecord type1 = new flightrecord();
		type1.setVisible(false);
		@SuppressWarnings("unused")
		DomesticFlight d1 = new DomesticFlight(type1);
	}
}

class button3 implements ActionListener {
	static final String DB_URL = "jdbc:mysql://localhost/airline_system";
	static final String USER = "root";
	static final String PASS = "";
	DomesticFlight type;
	flightrecord type1;

	button3(DomesticFlight type, flightrecord type1) {
		this.type = type;
		this.type1 = type1;
	}

	public void actionPerformed(ActionEvent e) {
		String sFrom = (String) type.CBFrom.getSelectedItem();
		String sTo = (String) type.CBTo.getSelectedItem();
		String sClass = (String) type.CBClass.getSelectedItem();
		String sBookingDate = type.TFBookingDate.getText();
		System.out.println(sBookingDate + " " + sClass + " " + sFrom + " " + sTo);
		int iPrice = 0;
		String sTime = "";

		int iAdult = Integer.parseInt((String) type.CBAdult.getSelectedItem());
		int iChildren = Integer.parseInt((String) type.CBChildren.getSelectedItem());
		int iInfant = Integer.parseInt((String) type.CBInfant.getSelectedItem());

		int i = 0;

		if (sClass.equals("Economic")) {
			System.out.println(type1.row1[i][1] + " " + type1.row1[i][2]);
			if (type1.row1[i][1].equals(sTo)) {

				iPrice = Integer.parseInt((String) type1.row1[i][2]);
				sTime = (String) type1.row1[i][3];
				type.setTitle(iPrice + " " + sTime);

			}
			i++;

		} else {
			if (type1.row1[i][1].equals(sTo)) {
				iPrice = Integer.parseInt((String) type1.row3[i][2]);
				sTime = (String) type1.row3[i][3];

			}
			i++;

		}
		System.out.println(type1.row1[i][2] + " " + type1.row1[i][3]);

		iPrice = (iPrice * iAdult) + (iPrice * (iChildren / 2));
		int iSeatCount = 0;

		iSeatCount = iSeatCount + iAdult + iChildren + iInfant;

		if (iSeatCount > 5) {
			JOptionPane.showMessageDialog(null, "Seats are full. Sorry!");
		} else {
			int iChoice = JOptionPane.showConfirmDialog(null, "Seats available. Do you want to Book now?");
			if (iChoice == JOptionPane.YES_OPTION) {
				
				type1.setVisible(false);
				new PrintTicket1(sFrom, sTo, sClass, iAdult, iChildren, iInfant, sBookingDate, iPrice, sTime);
				Connection conn=null;
			
				java.sql.Statement stmt = null;

    		    try{
    		    	Class.forName("com.mysql.jdbc.Driver");
    		    	System.out.println("Connection to database...");
    		    	conn=DriverManager.getConnection(DB_URL,USER,PASS);
    		    	System.out.println("Creating statement...");
    		    	stmt = conn.createStatement();
					String sql;
					sql = "SELECT occurrence FROM `flights` WHERE from_country=\'" + sFrom + "\'AND to_country=\'" + sTo + "\' AND class=\'" + sClass + "\'" ;
					ResultSet rs=stmt.executeQuery(sql);
				 if (rs.next() == false) {
					 PreparedStatement stmt1=conn.prepareStatement("insert into flights values(?,?,?,?)");
		    	     	stmt1.setString(1,sFrom);
		    	     	stmt1.setString(3,sTo);
		    	     	stmt1.setInt(2,1);
		    	     	stmt1.setString(4, sClass);
		    	     	int i1 = stmt1.executeUpdate();
				      } else {

				        do {
				        	int occurrence = rs.getInt("occurrence");
				        	PreparedStatement stmt1=conn.prepareStatement("UPDATE `flights` SET `occurrence`= ? WHERE from_country=\'" + sFrom + "\'AND to_country=\'" + sTo + "\' AND class=\'" + sClass + "\'" );
			    	     	stmt1.setInt(1,occurrence+1);
			    	     	int i1 = stmt1.executeUpdate();
				        	

				        } while (rs.next());
				      }

    		    }
		    catch(Exception e1){
		    	System.out.println(e1);
		    }
    		   
    		    
			} else {
			}
		}
	}

}