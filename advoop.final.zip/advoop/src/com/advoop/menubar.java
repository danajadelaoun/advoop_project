package com.advoop;


import java.io.FileNotFoundException;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class menubar extends Application {

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws FileNotFoundException {
		primaryStage.setTitle("AirLine-Ticket-Reservation");
		// menu bar
		MenuBar menuBar = new MenuBar();
		Menu menu1 = new Menu("AirLine System	");
		MenuItem menuItem1 = new MenuItem("Customer Details");
		MenuItem menuItem2 = new MenuItem("View Customer");
		MenuItem menuItem4 = new MenuItem("Flight Info");
		MenuItem menuItem5 = new MenuItem("Report");
		MenuItem menuItem6 = new MenuItem("Reserve a ticket");
		menu1.getItems().add(menuItem1);
		menu1.getItems().add(menuItem2);
//		menu1.getItems().add(menuItem3);
		menu1.getItems().add(menuItem4);
		menu1.getItems().add(menuItem5);
		menu1.getItems().add(menuItem6);
		menuBar.getMenus().add(menu1);
		VBox vBox = new VBox(menuBar);
//		Image image = new Image((new FileInputStream("C:\\Users\\USER\\Pictures\\bg-photo1.jpg")));
//		ImageView imageView = new ImageView(image);
//		imageView.setX(0);
//		imageView.setY(0);
//		imageView.setFitHeight(900);
//		imageView.setFitWidth(1000);
//		imageView.setPreserveRatio(true);

		Label l5 = new Label("Middle East AirLines");
		l5.setFont(Font.font("", FontWeight.BOLD, 40));
		l5.setLayoutX(20);
		l5.setLayoutY(40);
		vBox.getChildren().add(l5);
//		vBox.getChildren().add(imageView);

		// end of menu bar

		// add event for menu item
		menuItem1.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				customer_details c1 = new customer_details();
				Stage primaryStage2 = new Stage();
				try {
					c1.start(primaryStage2);
					primaryStage.close();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		});

		menuItem2.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				view_customer c1 = new view_customer();
				Stage primaryStage2 = new Stage();
				try {
					c1.start(primaryStage2);
					primaryStage.close();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		menuItem4.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				flightrecord c1 = new flightrecord();

			}
		});
		menuItem6.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				flightrecord type = new flightrecord() ;
				type.setVisible(false);
				DomesticFlight c1 = new DomesticFlight(type);

			}
		});
		
		menuItem5.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				report type = new report() ;
				Stage primaryStage2 = new Stage();
				try {
					type.start(primaryStage2);
					primaryStage.close();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				
			}
			}
		});
		

		// end event menu item
		Scene scene = new Scene(vBox, 960, 600);

		primaryStage.setScene(scene);
		primaryStage.show();
	}
}