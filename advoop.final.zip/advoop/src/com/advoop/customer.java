package com.advoop;

public class customer {
String name;
String fname;
int id;

	int phone_number;
	
    public customer() {
        
    }
    
	public customer(String n, String f,int i,  int p) {
		super();
		this.name = n;
		this.fname = f;
		this.id=i;
		this.phone_number = p;
	}

	public int getphone_number() {
		return phone_number;
	}

	public void setphone_number(int p) {
		this.phone_number = p;
	}

	public String getname() {
		return name;
	}

	public void setname(String n) {
		this.name = n;
	}

	public String getfname() {
		return fname;
	}

	public void setfname(String f) {
		this.fname = f;
	}
	
	public int getid() {
		return id;
	}

	public void setid(int n) {
		this.id = n;
	}
	@Override
	public String toString() {
		return "name=" + name + ", father name=" + fname + ", phone number=" + phone_number;
	}
}
