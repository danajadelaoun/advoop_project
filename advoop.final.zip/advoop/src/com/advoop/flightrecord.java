package com.advoop;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;

import javax.swing.text.*;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
class WindowUtilities 
{
	public static void setNativeLookAndFeel() 
	{
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e)
		{
			System.out.println("Error setting native LAF: " + e);
		}
	}
//UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
//UIManager.setLookAndFeel( "com.sun.java.swing.plaf.motif.MotifLookAndFeel");
}
public class flightrecord extends JFrame {
	Container c = getContentPane();
	JPanel PFlightTypes = new JPanel(null);
	JPanel PLogin = new JPanel(null);
	JPanel PFlightDetails = new JPanel(null);

	public boolean bCheck = true;

	JLabel LDomesticFlight = new JLabel("<html><B>Domestic Flights</B></html>");
	JLabel LInternationalFlight = new JLabel("<html><B>International Flights</B></html>");

	JLabel LDomesticFlight1 = new JLabel("<html><B>Domestic Flight Booking</B></html>");
	JLabel LInternationalFlight1 = new JLabel("<html><B>International Flight Booking</B></html>");

	final Object[] col1 = { "From", "To", "Price", "Time" };
	final Object[] col2 = { "From", "To", "Price", "Time" };
	final Object[] col3 = { "From", "To", "Price", "Time" };

	final Object[][] row1 = { { "Lebanon", "Bangalore", "3125", "16:30" }, { "Lebanon", "Chennai ", "3225", "19:00" },
			{ "Lebanon", "Delhi", "1425 ", "08:30" }, { "Lebanon", "Goa", "1025 ", "09:50" },
			{ "Lebanon", "Hyderabad", "1525", "11:00" }, { "Lebanon", "Kolkata", "3825 ", "05:30" },
			{ "Lebanon", "Lucknow", "3025 ", "05:30" }, { "Lebanon", "Mumbai", "1725", "12:00" },
			{ "Lebanon", "Vishakapatnam", "3725", "19:00" } };
	final Object[][] row2 = { { "Lebanon", "Bali", "21485", "06:20" }, { "Lebanon", "Bangkok", "9000", "20:45" },
			{ "Lebanon", "Cairo", "22975", "10:25" }, { "Lebanon", "CapeTown", "42500", "16:45" },
			{ "Lebanon", "Chicago", "35000", "06:30" }, { "Lebanon", "Dubai", "12000", "08:15" },
			{ "Lebanon", "Frankfurt", "18500", "06:50" }, { "Lebanon", "HongKong", "20845", "12:00" },
			{ "Lebanon", "Istanbul", "22000", "10:45" }, { "Lebanon", "London", "22600", "14:35" },
			{ "Lebanon", "LosAngeles", "35000", "22:00" }, { "Lebanon", "Melbourne", "27800", "21:15" },
			{ "Lebanon", "New York", "32000", "08:50" }, { "Lebanon", "Paris", "18500", "18:45" },
			{ "Lebanon", "Rome", "19900", "20:00" }, { "Lebanon", "SanFrancisco", "35000", "12:00" },
			{ "Lebanon", "shanghai", "24430", "10:15" }, { "Lebanon", "Singapore", "9000", "21:10" },
			{ "Lebanon", "Sydney", "27800", "12:00" }, { "Lebanon", "Toronto", "35000", "17:00 " } };
	final Object[][] row3 = { { "Lebanon", "Bangalore", "9375", "16:30" }, { "Lebanon", "Chennai ", "9675", "19:00" },
			{ "Lebanon", "Delhi", "4275", "08:30" }, { "Lebanon", "Goa", "3075", "09:50" },
			{ "Lebanon", "Hyderabad", "4575", "11:00" }, { "Lebanon", "Kolkata", "11475", "05:30" },
			{ "Lebanon", "Lucknow", "9075", "05:30" }, { "Lebanon", "Mumbai", "5175", "12:00" },
			{ "Lebanon", "Vishakapatnam", "11175", "19:00" } };
	final Object[][] row4 = { { "Lebanon", "Bali", "64455", "06:20" }, { "Lebanon", "Bangkok", "27000", "20:45" },
			{ "Lebanon", "Cairo", "68925", "10:25" }, { "Lebanon", "CapeTown", "37500", "16:45" },
			{ "Lebanon", "Chicago", "105000", "06:30" }, { "Lebanon", "Dubai", "36000", "08:15" },
			{ "Lebanon", "Frankfurt", "55500", "06:50" }, { "Lebanon", "HongKong", "62535", "12:00" },
			{ "Lebanon", "Istanbul", "66000", "10:45" }, { "Lebanon", "London", "67800", "14:35" },
			{ "Lebanon", "LosAngeles", "105000", "22:00" }, { "Lebanon", "Melbourne", "83400", "21:15" },
			{ "Lebanon", "New York", "96000", "08:50" }, { "Lebanon", "Paris", "55500", "18:45" },
			{ "Lebanon", "Rome", "59700", "20:00" }, { "Lebanon", "SanFrancisco", "105000", "12:00" },
			{ "Lebanon", "shanghai", "73290", "10:15" }, { "Lebanon", "Singapore", "27000", "21:10" },
			{ "Lebanon", "Sydney", "83400", "12:00" }, { "Lebanon", "Toronto", "105000", "17:00" } };

	JTable TDomesticFlight = new JTable(row1, col1);
	JTable TInternationalFlight = new JTable(row2, col2);
	JTable TDomesticFlight1 = new JTable(row3, col3);
	JTable TInternationalFlight1 = new JTable(row4, col2);

	JScrollPane JSP1 = new JScrollPane(TDomesticFlight, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
			ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JScrollPane JSP2 = new JScrollPane(TInternationalFlight, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
			ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JScrollPane JSP3 = new JScrollPane(TDomesticFlight1, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
			ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JScrollPane JSP4 = new JScrollPane(TInternationalFlight1, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
			ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);

	JLabel LEconomic = new JLabel("Economic", SwingConstants.LEFT);
	JLabel LBusiness = new JLabel("Business", SwingConstants.LEFT);
	JLabel LEconomic1 = new JLabel("Economic", SwingConstants.LEFT);
	JLabel LBusiness1 = new JLabel("Business", SwingConstants.LEFT);

	public flightrecord() {
		
		WindowUtilities.setNativeLookAndFeel();
		setPreferredSize(new Dimension(805, 572));
		JButton bt1 = new JButton("back");
		bt1.setBounds(700, 20, 70, 30);
		Icon bug1 = new ImageIcon("C:\\Users\\USER\\Pictures\\bg-photo1.jpg");
		JLabel j1 = new JLabel();
		j1.setIcon(bug1);
		j1.setBounds(0, 0, 850, 340);

		PFlightDetails.setBackground(Color.white);

		JSP1.setBounds(0, 340, 790, 200);
		JSP2.setBounds(0, 340, 790, 200);
		JSP3.setBounds(0, 340, 790, 200);
		JSP4.setBounds(0, 340, 790, 200);

		PFlightTypes.setBounds(0, 0, 850, 340);
		PLogin.setBounds(500, 0, 350, 340);
		PFlightDetails.setBounds(0, 340, 790, 200);
		bt1.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent e) {
				menubar c1 = new menubar() {
				};
				Stage primaryStage2 = new Stage();

				try {
					c1.start(primaryStage2);
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});

		LDomesticFlight1.setBounds(425, 60, 138, 20);
		LInternationalFlight1.setBounds(425, 100, 153, 20);

		PFlightDetails.add(JSP1);
		PFlightDetails.add(JSP2);
		PFlightDetails.add(JSP3);
		PFlightDetails.add(JSP4);

		JSP1.setVisible(false);
		JSP2.setVisible(true);
		JSP3.setVisible(false);
		JSP4.setVisible(false);

		LBusiness.setBounds(530, 170, 300, 125);
		LEconomic.setBounds(230, 170, 250, 125);
		LBusiness1.setBounds(500, 200, 135, 60);
		LEconomic1.setBounds(260, 200, 147, 60);

		PFlightTypes.add(LEconomic);
		PFlightTypes.add(LBusiness);
		PFlightTypes.add(LEconomic1);
		PFlightTypes.add(LBusiness1);

		LBusiness.setVisible(false);
		LEconomic1.setVisible(false);
		LBusiness1.setVisible(true);
		LEconomic.setVisible(true);

		LDomesticFlight.setBounds(30, 60, 100, 25);
		LInternationalFlight.setBounds(30, 100, 120, 25);

		c.add(PFlightTypes);
		c.add(PLogin);
		c.add(PFlightDetails);

		PFlightTypes.add(LDomesticFlight);
		PFlightTypes.add(LInternationalFlight);
		PFlightTypes.add(j1);

		pack();
		setVisible(true);

//		addWindowListener(new WindowListener());

		LDomesticFlight.addMouseListener(new mouse1(this, true));
		LInternationalFlight.addMouseListener(new mouse1(this, false));

		/*
		 * LDomesticFlight1.addMouseListener(new mouse3(this, true));
		 * LInternationalFlight1.addMouseListener(new mouse3(this, false));
		 */

		LBusiness1.addMouseListener(new mouse2(this, true));
		LEconomic1.addMouseListener(new mouse2(this, false));

	}

	public static void main(String args[]) {
		new flightrecord();

	}
}

class mouse1 extends MouseAdapter {
	flightrecord type;
	boolean bCheck;

	public mouse1(flightrecord type, boolean bCheck) {
		this.type = type;
		this.bCheck = bCheck;
	}

	public void mouseEntered(MouseEvent e) {
		type.LDomesticFlight.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		type.LInternationalFlight.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseClicked(MouseEvent e) {
		if (bCheck)
			type.bCheck = true;
		else
			type.bCheck = false;
		type.LEconomic.setVisible(true);
		type.LBusiness1.setVisible(true);
		type.LEconomic1.setVisible(false);
		type.LBusiness.setVisible(false);

		type.JSP1.setVisible(false);
		type.JSP2.setVisible(false);
		type.JSP3.setVisible(false);
		type.JSP4.setVisible(false);
		if (bCheck)
			type.JSP1.setVisible(true);
		else
			type.JSP2.setVisible(true);
	}
}

/*
 * class mouse3 extends MouseAdapter { flightrecord type; boolean bCheck;
 * 
 * public mouse3(flightrecord type, boolean bCheck) { this.type = type; this.bCheck
 * = bCheck; } public void mouseEntered(MouseEvent e) {
 * type.LDomesticFlight1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR
 * )); type.LInternationalFlight1.setCursor(Cursor.getPredefinedCursor(Cursor.
 * HAND_CURSOR)); } public void mouseClicked(MouseEvent e) { if (bCheck) new
 * DomesticFlight(type); else new InternationalFlight(type); } }
 */

class mouse2 extends MouseAdapter {
	flightrecord type;
	boolean bCheck;

	public mouse2(flightrecord type, boolean bCheck) {
		this.type = type;
		this.bCheck = bCheck;
	}

	public void mouseEntered(MouseEvent e) {
		type.LEconomic1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		type.LBusiness1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	public void mouseClicked(MouseEvent e) {
		if (type.bCheck) {
			if (bCheck) {
				type.LBusiness1.setVisible(false);
				type.LBusiness.setVisible(true);
				type.LEconomic.setVisible(false);
				type.LEconomic1.setVisible(true);
				type.JSP1.setVisible(false);
				type.JSP2.setVisible(false);
				type.JSP3.setVisible(true);
				type.JSP4.setVisible(false);
			} else {
				type.LEconomic1.setVisible(false);
				type.LBusiness.setVisible(false);
				type.LBusiness1.setVisible(true);
				type.LEconomic.setVisible(true);
				type.JSP1.setVisible(true);
				type.JSP2.setVisible(false);
				type.JSP3.setVisible(true);
				type.JSP4.setVisible(false);
			}
		} else {
			if (bCheck) {
				type.LBusiness1.setVisible(false);
				type.LBusiness.setVisible(true);
				type.LEconomic.setVisible(false);
				type.LEconomic1.setVisible(true);
				type.JSP1.setVisible(false);
				type.JSP2.setVisible(false);
				type.JSP3.setVisible(false);
				type.JSP4.setVisible(true);
			} else {
				type.LEconomic1.setVisible(false);
				type.LBusiness.setVisible(false);
				type.LBusiness1.setVisible(true);
				type.LEconomic.setVisible(true);
				type.JSP1.setVisible(false);
				type.JSP2.setVisible(true);
				type.JSP3.setVisible(false);
				type.JSP4.setVisible(false);
			}
		}
	}
}
