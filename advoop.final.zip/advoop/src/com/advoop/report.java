package com.advoop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Random;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;
 
public class report extends Application {
	static final String DB_URL = "jdbc:mysql://localhost/airline_system";
	static final String USER = "root";
	static final String PASS = "";
 
    int group[] = new int[10];
 
    @Override
    public void start(Stage primaryStage) {
 
        prepareData();
 
        Label labelInfo = new Label();
 
        //barChart1 with setAnimated(false)
        VBox vBoxBarChart1 = new VBox();
        XYChart.Series series1 = new XYChart.Series();
        series1.getData().add(new XYChart.Data("Bangalore", group[0]));
        series1.getData().add(new XYChart.Data("Delhi", group[1]));
        series1.getData().add(new XYChart.Data("Lucknow", group[2]));
        series1.getData().add(new XYChart.Data("Hyderabad", group[3]));
        series1.getData().add(new XYChart.Data("Vishakapatnam", group[4]));
        series1.getData().add(new XYChart.Data("Chennai", group[5]));
        series1.getData().add(new XYChart.Data("Goa", group[6]));
        series1.getData().add(new XYChart.Data("Kolkata", group[7]));
        series1.getData().add(new XYChart.Data("Mumbai", group[8]));
        series1.getData().add(new XYChart.Data("CapeTown", group[9]));
 
 
        Label labelAnimated1 = new Label();
        //- End of barChart1
 
        //PieChart2 with setAnimated(false)
        VBox vBoxPieChart2 = new VBox();
 
        ObservableList<PieChart.Data> pieChartData
                = FXCollections.observableArrayList(
                        new PieChart.Data("Bangalore", group[0]),
                        new PieChart.Data("Delhi", group[1]),
                        new PieChart.Data("Lucknow", group[2]),
                        new PieChart.Data("Hyderabad", group[3]),
                        new PieChart.Data("Vishakapatnam", group[4]),
                        new PieChart.Data("Chennai", group[5]),
                        new PieChart.Data("Goa", group[6]),
                        new PieChart.Data("Kolkata", group[7]),
                        new PieChart.Data("Mumbai", group[8]),
                        new PieChart.Data("CapeTown", group[9])
                );
         
        final PieChart pieChart2
                = new PieChart(pieChartData);
        pieChart2.setMaxSize(500, 450);
 
        Label labelAnimated2 = new Label();
        pieChart2.setAnimated(true);
        vBoxPieChart2.getChildren().addAll(pieChart2, labelAnimated2);
        //- End of pieChart2
 
        HBox hBoxCharts = new HBox();
        hBoxCharts.getChildren().addAll(vBoxBarChart1, vBoxPieChart2);
 
        Label labelCnt = new Label();
 
        VBox vBox = new VBox();
        vBox.getChildren().addAll(labelInfo, hBoxCharts, labelCnt);
 
        StackPane root = new StackPane();
        root.getChildren().add(vBox);
 
        Scene scene = new Scene(root, 500, 500);
 
        primaryStage.setTitle("Statistics");
        primaryStage.setScene(scene);
        primaryStage.show();
 
        Timeline timeline = new Timeline();
        timeline.getKeyFrames().add(
                new KeyFrame(Duration.millis(10), (ActionEvent actionEvent) -> {
                	Connection conn=null;
        			String oc;
    				java.sql.Statement stmt = null;

        		    try{
        		    	Class.forName("com.mysql.jdbc.Driver");
        		    	System.out.println("Connection to database...");
        		    	conn=DriverManager.getConnection(DB_URL,USER,PASS);
        		    	System.out.println("Creating statement...");
        		    	stmt = conn.createStatement();
    					String sql;
    					String sto= "Bangalore";
    					sql = "SELECT * FROM `flights`" ;
    					ResultSet rs=stmt.executeQuery(sql);
    			
    					while (rs.next()){
    				        	oc= rs.getString("to_country");
    				        	if (oc.equals("Bangalore")) {
    		                        group[0]++;
    		                        series1.getData().set(0, new XYChart.Data("Bangalore", group[0]));
    		                        pieChartData.set(0, new PieChart.Data("Bangalore", group[0]));
    		                    } else if (oc.equals("Delhi")) {
    		                        group[1]++;
    		                        series1.getData().set(1, new XYChart.Data("Delhi", group[1]));
    		                        pieChartData.set(1, new PieChart.Data("Delhi", group[1]));
    		                    } else if (oc.equals("Lucknow")) {
    		                        group[2]++;
    		                        series1.getData().set(2, new XYChart.Data("Lucknow", group[2]));
    		                        pieChartData.set(2, new PieChart.Data("Lucknow", group[2]));
    		                    } else if (oc.equals("Hyderabad")) {
    		                        group[3]++;
    		                        series1.getData().set(3, new XYChart.Data("Hyderabad", group[3]));
    		                        pieChartData.set(3, new PieChart.Data("Hyderabad", group[3]));
    		                    } else if (oc.equals("Vishakapatnam")) {
    		                        group[4]++;
    		                        series1.getData().set(4, new XYChart.Data("Vishakapatnam", group[4]));
    		                        pieChartData.set(4, new PieChart.Data("Vishakapatnam", group[4]));
    		                    } else if (oc.equals("Chennai")) {
    		                        group[5]++;
    		                        series1.getData().set(5, new XYChart.Data("Chennai", group[5]));
    		                        pieChartData.set(5, new PieChart.Data("Chennai", group[5]));
    		                    } else if (oc.equals("Goa")) {
    		                        group[6]++;
    		                        series1.getData().set(6, new XYChart.Data("Goa", group[6]));
    		                        pieChartData.set(6, new PieChart.Data("Goa", group[6]));
    		                    } else if (oc.equals("Kolkata")) {
    		                        group[7]++;
    		                        series1.getData().set(7, new XYChart.Data("Kolkata", group[7]));
    		                        pieChartData.set(7, new PieChart.Data("Kolkata", group[7]));
    		                    } else if (oc.equals("Mumbai")) {
    		                        group[8]++;
    		                        series1.getData().set(8, new XYChart.Data("Mumbai", group[8]));
    		                        pieChartData.set(8, new PieChart.Data("Mumbai", group[8]));
    		                    } else if (oc.equals("CapeTown")) {
    		                        group[9]++;
    		                        series1.getData().set(9, new XYChart.Data("CapeTown", group[9]));
    		                        pieChartData.set(9, new PieChart.Data("CapeTown", group[9]));
    		                    }

    				        } 
    				      

        		    }
    		    catch(Exception e1){
    		    	System.out.println(e1);
    		    }

 
                    
                   
                                  }));
 
        timeline.setCycleCount(20);
        timeline.setAutoReverse(true); 
        timeline.play();
        
 
    }
 
    public static void main(String[] args) {
        launch(args);
    }
 
    //generate dummy random data
    private void prepareData() {
        for (int i = 0; i < 10; i++) {
            group[i] = 0;
        }
    }
 
}