package com.advoop;


import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class login extends Application {

	static final String DB_URL = "jdbc:mysql://localhost/airline_system";
	static final String USER = "root";
	static final String PASS = "";

	public void start(Stage primaryStage) {
		primaryStage.setTitle("Welcome to MEA");

		GridPane grid = new GridPane();
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Scene scene = new Scene(grid, 300, 275);
		primaryStage.setScene(scene);

		Text scenetitle = new Text("Welcome");
		grid.add(scenetitle, 0, 0, 2, 1);

		Label userName = new Label("User Name:");
		grid.add(userName, 0, 1);

		TextField userTextField = new TextField();
		grid.add(userTextField, 1, 1);

		Label pw = new Label("Password:");
		grid.add(pw, 0, 2);

		PasswordField pwBox = new PasswordField();
		grid.add(pwBox, 1, 2);

		Button btn = new Button("Sign in");
		HBox hbBtn = new HBox(10);
		hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
		hbBtn.getChildren().add(btn);
		grid.add(hbBtn, 1, 4);
		

		final Text actiontarget = new Text();
		grid.add(actiontarget, 1, 6);

		btn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Connection conn = null;
				java.sql.Statement stmt = null;
				try {
					Class.forName("com.mysql.jdbc.Driver");
					System.out.println("Connection to database...");
					conn = DriverManager.getConnection(DB_URL, USER, PASS);
					System.out.println("Creating statement...");
					stmt = conn.createStatement();
					String sql;
					
					String name=userTextField.getText();
					String password=pwBox.getText();
					sql = "select * from users where name='"+name+"' AND password='"+password+"'";
					ResultSet rs = stmt.executeQuery(sql);
					
					 if (rs.next() == false) {
						 Alert a1 = new Alert(AlertType.ERROR,  
					                "Error either in user name or passwrod",ButtonType.OK); 
					    			a1.setTitle("No Result Found");
					    			 a1.show();
					      } else {
//					    	  payment p1=new payment(name);
					    		menubar c1 = new menubar() {
								};
								Stage primaryStage2 = new Stage();
								try {
									c1.start(primaryStage2);
									primaryStage.close();
								} catch (Exception e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
					      }
				}


				catch (Exception e1) {
					System.out.println(e1);
				

			}
				
				
//				
			}
		});
		scenetitle.setId("welcome-text");
		actiontarget.setId("actiontarget");

		scene.getStylesheets().add(login.class.getResource("style.css").toExternalForm());

		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}