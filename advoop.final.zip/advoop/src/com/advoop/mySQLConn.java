package com.advoop;

	import java.sql.*;

	public class mySQLConn {
		
		public static boolean isConn;
		private static Connection conn;
		
		static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
		static final String DB_URL = "jdbc:mysql://localhost/airline_system";
		static final String USER = "root";
		static final String PASS = "";
		
		public static Connection DBconn() {
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("Connecting to database...");
				conn = DriverManager.getConnection(DB_URL, USER, PASS);
				
				isConn = true;
				System.out.println("Connection set.");
				return conn;
				
			}catch(Exception e) {
				System.out.println("Error.....");
				isConn = false;
				return null;
				
			}
		
	}

}
