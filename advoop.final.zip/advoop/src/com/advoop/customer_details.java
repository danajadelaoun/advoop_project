package com.advoop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;  
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;  
import javafx.scene.text.Font;  
import javafx.scene.text.FontPosture;  
import javafx.scene.text.FontWeight;  
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;  
public class customer_details extends Application{  
	static final String DB_URL="jdbc:mysql://localhost/airline_system";
	static final String USER = "root";
	static final String PASS = "";
ComboBox<Integer> year,month,day;
String path1;
public void start(Stage primaryStage) throws Exception {  
	
	Group root = new Group(); 
//title
Text text = new Text();  
primaryStage.setTitle("CUSTOMER_DETAILS");
    text.setX(0);    
    text.setY(30);  
    text.setFont(Font.font("Abyssinica SIL",FontWeight.BOLD,FontPosture.REGULAR,30));  
    text.setFill(Color.BLUE);//setting colour of the text to blue   
    text.setStroke(Color.BLACK); // setting the stroke for the text    
    text.setStrokeWidth(1); // setting stroke width to 2   
    text.setText("			      Customer Details						  ");   
    text.setUnderline(true);
    root.getChildren().add(text);  
// end of title
    
//body
 Label l1= new Label("Customer_ID");
 l1.setFont(Font.font("",FontWeight.BOLD,20));
 l1.setLayoutX(20);
 l1.setLayoutY(50);
 root.getChildren().add(l1);
 
 Label l2= new Label("Customer_NAME");
 l2.setFont(Font.font("",FontWeight.BOLD,20));
 l2.setLayoutX(20);
 l2.setLayoutY(90);
 root.getChildren().add(l2);
 
 Label l3= new Label("Father_NAME");
 l3.setFont(Font.font("",FontWeight.BOLD,20));
 l3.setLayoutX(20);
 l3.setLayoutY(130);
 root.getChildren().add(l3);
 
 Label l4= new Label("Gender");
 l4.setFont(Font.font("",FontWeight.BOLD,20));
 l4.setLayoutX(20);
 l4.setLayoutY(170);
 root.getChildren().add(l4);
 
 Label l5= new Label("Date_of_birth");
 l5.setFont(Font.font("",FontWeight.BOLD,20));
 l5.setLayoutX(20);
 l5.setLayoutY(210);
 root.getChildren().add(l5);
 
 Label l6= new Label("Phone_NUMBER");
 l6.setFont(Font.font("",FontWeight.BOLD,20));
 l6.setLayoutX(20);
 l6.setLayoutY(250);
 root.getChildren().add(l6);
 
 Label l7= new Label("ADDRESS");
 l7.setFont(Font.font("",FontWeight.BOLD,20));
 l7.setLayoutX(20);
 l7.setLayoutY(290);
 root.getChildren().add(l7);
 
 Label l8= new Label("Choose_IMAGE");
 l8.setFont(Font.font("",FontWeight.BOLD,20));
 l8.setLayoutX(500);
 l8.setLayoutY(50);
 root.getChildren().add(l8);
 
 TextField t1=new TextField();
 t1.setLayoutX(290);
 t1.setLayoutY(50);
 root.getChildren().add(t1);
 
 TextField t2=new TextField();
 t2.setLayoutX(290);
 t2.setLayoutY(90);
 root.getChildren().add(t2);

 TextField t3=new TextField();
 t3.setLayoutX(290);
 t3.setLayoutY(130);
 root.getChildren().add(t3);
 
 // Group
 ToggleGroup group = new ToggleGroup();

 // Radio 1: Male
 RadioButton b1 = new RadioButton("Female");
 b1.setLayoutX(290);
 b1.setLayoutY(170);
 b1.setToggleGroup(group);
 b1.setSelected(true);

 // Radio 3: Female.
 RadioButton b2 = new RadioButton("Male");
 b2.setLayoutX(390);
 b2.setLayoutY(170);
 b2.setToggleGroup(group);
 root.getChildren().addAll(b1,b2);
 
 
 int days[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31};
 int months[]={1,2,3,4,5,6,7,8,9,10,11,12};
 int years[]={1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2009};
  day = new ComboBox<Integer>();
day.setLayoutX(290);
day.setLayoutY(210);
for(int i =0;i<days.length;i++)
 day.getItems().add(days[i]);
root.getChildren().add(day);

 month = new ComboBox<Integer>();
month.setLayoutX(350);
month.setLayoutY(210);
for(int i =0;i<months.length;i++)
month.getItems().add(months[i]);
root.getChildren().add(month);

 year = new ComboBox<Integer>();
year.setLayoutX(410);
year.setLayoutY(210);
for(int i =0;i<years.length;i++)
year.getItems().add(years[i]);
root.getChildren().add(year);


TextField t6=new TextField();
 t6.setLayoutX(290);
 t6.setLayoutY(250);
 root.getChildren().add(t6);
 TextArea t7=new TextArea();

t7.setPrefHeight(150);
 t7.setLayoutX(290);
 t7.setLayoutY(290);
 root.getChildren().add(t7);
 
 Button btn1=new Button("Save");
 btn1.setPrefWidth(100);
 btn1.setLayoutX(320);
 btn1.setLayoutY(470);
 root.getChildren().add(btn1);
 
 Button btn3=new Button("back");
 btn3.setPrefWidth(100);
 btn3.setLayoutX(680);
 btn3.setLayoutY(470);
 root.getChildren().add(btn3);
 
 Button btn2=new Button("Choose file");
 btn2.setLayoutY(50);
 btn2.setLayoutX(670);
 root.getChildren().add(btn2);
 
 

 
//end of body
 
//add event 
 
//Creating the mouse event handler 
EventHandler<MouseEvent> eventHandler = new EventHandler<MouseEvent>() { 
    @Override 
    public void handle(MouseEvent e) {
    	if (!t1.getText().isEmpty() && !t2.getText().isEmpty() && !t3.getText().isEmpty() && !t6.getText().isEmpty() && !t7.getText().isEmpty() && !month.getSelectionModel().isEmpty() && !day.getSelectionModel().isEmpty() && !year.getSelectionModel().isEmpty() ){
    		    		if(b1.isSelected()|| b2.isSelected()){
    			Connection conn=null;
    		    try{
    		    	Class.forName("com.mysql.jdbc.Driver");
    		    	System.out.println("Connection to database...");
    		    	conn=DriverManager.getConnection(DB_URL,USER,PASS);
    		    	System.out.println("Creating statement...");
    		    	int getyear=year.getValue();
    		    	int getday=day.getValue();
    		    	int getmonth=month.getValue();
    		    	String date = getyear+"-"+getmonth+"-"+getday;
    		    	int id=Integer.parseInt(t1.getText());
    		    	System.out.println(id);
    		    	String fname=t3.getText();
    		    	String gender;
    		    	if(b1.isSelected()){
    		    		gender="female";
    		    		
    		    	}
    		    	else
    		    		gender="male";
    		    	PreparedStatement stmt1=conn.prepareStatement("insert into   		customer values(?,?,?,?,?,?,?)");
    		    	     	stmt1.setString(2,t2.getText());//1 specifies 1st parameter in the query
    		    	     	stmt1.setString(3,fname);
    		    	     	stmt1.setInt(1,id);
    		    	     	stmt1.setString(4,gender);
    		    	     	 stmt1.setDate(5, Date.valueOf(date));
    		    	     	stmt1.setString(7,t7.getText());
    		    	     	stmt1.setInt(6,Integer.parseInt(t6.getText()));
    		    	     
    		    	     	/*FileInputStream fin = new FileInputStream("C:\\Users\\USER\\Desktop\\form-img.jpeg");
    		    	     	stmt1.setBinaryStream(8, fin,fin.available());
    		    	     	*/
    		    	     	
    		    	     	int i =stmt1.executeUpdate();
    		    	      System.out.println(i);
    		    	      if (i==1){

      		    	        
    		    	    	  Alert a1 = new Alert(AlertType.NONE,  
    		    	                  "Thanks for subscribing for DJ air lines",ButtonType.OK); 
    		    	      			a1.setTitle("THANK YOU");
    		    	      			ProgressIndicator PI=new ProgressIndicator();  
    	      		    	          
    	      		    	        StackPane root = new StackPane();  
    	      		    	        root.getChildren().add(PI);  
    	      		    	        Scene scene = new Scene(root,300,200);  
    	      		    	        primaryStage.setScene(scene);  
    	      		    	        primaryStage.setTitle("Progress Indicator Example");  
    	      		    	        primaryStage.show();  
    		    	      			 a1.show();
    		    	      		}
    		    	      
    		    	      else if (i!=1){
    		    	    	  Alert a1 = new Alert(AlertType.ERROR,  
    		    	                  "Error happened please try again",ButtonType.OK); 
    		    	      			a1.setTitle("THANK YOU");
    		    	      			 a1.show();
    		    	      }
    		    
    		    	      stmt1.close();
       		           conn.close();}

       		    catch(Exception e1){
       		    	System.out.println(e1);
       		    } 
    		    	  }
    	
    	}
 
    	else if (t1.getText().isEmpty() || t2.getText().isEmpty() || t3.getText().isEmpty() || t6.getText().isEmpty() || t7.getText().isEmpty() || month.getSelectionModel().isEmpty() || day.getSelectionModel().isEmpty() || year.getSelectionModel().isEmpty() ){
    		if(!b1.isSelected()|| !b2.isSelected()){
    	
    	Alert a1 = new Alert(AlertType.ERROR,  
                "Please above boxes can not be empty",ButtonType.OK); 
    			a1.setTitle("EMPTY INPUT");
    			 a1.show();
    		}
    	}
      
    }

	private int parseInt(String text) {
		// TODO Auto-generated method stub
		return 0;
	} 
 };  
 
 
 btn3.setOnAction(new EventHandler<ActionEvent>() {
     public void handle(ActionEvent event) {
    	 menubar c1= new menubar() {
		};
     	Stage primaryStage2=new Stage();
     	try {
				c1.start(primaryStage2);
				primaryStage.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
     }
   });
 
 btn2.setOnAction(new EventHandler<ActionEvent>() {
     public void handle(ActionEvent event) {
    	 FileChooser fileChooser = new FileChooser();
    	 fileChooser.setTitle("Open Resource File");
    	 File file = fileChooser.showOpenDialog(primaryStage);
    	 path1=file.getAbsolutePath();
    	 if (file!=null){
    		
    		Image image = null;
			try {
				image = new Image(new FileInputStream(path1));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
    		 ImageView imageView = new ImageView(image);  
    		 imageView.setX(500); 
    		 imageView.setY(100); 
    		 imageView.setFitHeight(300); 
    		 imageView.setFitWidth(250); 
    		 imageView.setPreserveRatio(true);  
    		 root.getChildren().add(imageView);
    	 
    	 }
    	 
    	 
    	 
     }
   });

 //Registering the event filter 
 btn1.addEventFilter(MouseEvent.MOUSE_CLICKED, eventHandler);   
 
     
    Scene scene = new Scene(root,800,500);  
  
    primaryStage.setScene(scene);  
    primaryStage.setTitle("Text Example");  primaryStage.show();  
}  

public static void main(String[] args) {  
    launch(args);  
    

}  


    


} 