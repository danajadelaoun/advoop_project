package com.advoop;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
//import application.Balance;
//import application.UserSession;
import javafx.collections.FXCollections;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("myresource")
public class MyResource {
	private Connection conn = null;
	private customers dataService = customers.getInstance();

	/**
	 * Method handling HTTP GET requests. The returned object will be sent to the
	 * client as "text/plain" media type.
	 *
	 * @return String that will be returned as a text/plain response.
	 */
	@GET
	@Path("/")
	@Produces(MediaType.TEXT_PLAIN)
	public String getIt() {
		return "Hello, Heroku!";
	}

	@POST
	@Path("/post")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response createcustomerInJSON(customer client) {

		String name = client.getname();
		String fname = client.getfname();
		int id= client.getid();
		int phone_number = client.getphone_number();
String address = null;
		try {

			conn = mySQLConn.DBconn();

			String sqlfrom = "SELECT * from customer where name=?";

			PreparedStatement stmtfrom = conn.prepareStatement(sqlfrom);
			stmtfrom.setString(1, name);
			ResultSet rsBalfrom = stmtfrom.executeQuery();
			
			while (rsBalfrom.next()) {

				address = rsBalfrom.getString("Address");
			}
			String newaddress;
			newaddress="Lebanon, beirut"+address;
			String sqlnewbalfrom = "Update customer set Address=? where name=?";
			PreparedStatement stmtnewBalfrom = conn.prepareStatement(sqlnewbalfrom);
			stmtnewBalfrom.setString(1, newaddress);
			stmtnewBalfrom.setString(2, name);

			int i = stmtnewBalfrom.executeUpdate();
			System.out.println(i + "inserted");
			
		} catch (Exception e) {
			System.out.println(e+ " error...");
		}
		String result = "customer done : [" + client + "] ";
		return Response.status(201).entity(result).build();
	}

	@GET
	@Path("/getAll")
	@Produces(MediaType.APPLICATION_JSON)
	public List<customer> getAllTracks() {
		return dataService.getcustomerList();
	}

	@GET
	@Path("{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getcustomerbyid(@PathParam("id")int id) {
		customer client = dataService.getcustomerbyid(id);
		if (client == null) {
			return Response.status(Response.Status.NOT_FOUND).build();
		} else {
			return Response.ok().entity(client).build();
		}
	}
}
